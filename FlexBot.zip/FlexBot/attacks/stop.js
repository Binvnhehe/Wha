const Discord = require("discord.js");


exports.run = async (client, message, args) => {
const config = require('../config.json');
var room = config.commandroom;
	if (message.channel.id != room) {
		return;
	}
	var exec = require('child_process').exec
		exec(`taskkill /f /im java.exe`, (error, stdout, stderr) => {
	});
	console.log('Dừng lại tất cả cuộc tấn công:' +  message.guild.id)
		message.reply('ALL STOP ATTACK!');
	 message.react('✅');
}

exports.conf = {
  aliases: []
};

exports.help = {
  name: "stop"
};