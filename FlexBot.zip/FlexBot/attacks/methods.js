const Discord = require("discord.js");


exports.run = async (client, message, args) => {
const config = require('../config.json');
var room = config.commandroom;
if (message.channel.id != room) {
	return;
  }
console.log('Xem tên phương pháp tấn công:' +  message.guild.id)
 message.reply("Auth, Byte, Bypass, CPU, TCP, JoinMotd, SlowJoin, Flood, Netty, Join, MOTD, Bungee, Spigot, XCord, Net, GAME, RAM");
 message.react('✅');
  }

exports.conf = {
  aliases: []
};

exports.help = {
  name: "methods"
};